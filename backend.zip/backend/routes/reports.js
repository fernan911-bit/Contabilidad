// En: backend/routes/reports.js
import { Router } from 'express';
import pool from '../db.js';

const router = Router();

// --- RUTA GET /api/reports/all ---
// (Obtiene todos los datos para la página de reportes)
router.get('/all', async (req, res) => {
  try {
    // 1. KPIs (Ingresos Totales, Ventas, Ticket Promedio, IVA)
    const [kpiResult] = await pool.query(
      `SELECT 
         SUM(total) AS ingresosTotales, 
         COUNT(*) AS ventasRealizadas, 
         AVG(total) AS ticketPromedio,
         SUM(iva) AS ivaRecaudado
       FROM Ventas`
    );
    const kpis = kpiResult[0];

    // 2. Ventas por Día de la Semana (Gráfico de Barras)
    // DAYOFWEEK() 1=Dom, 2=Lun, 3=Mar...
    const [salesByDay] = await pool.query(
      `SELECT 
         CASE DAYOFWEEK(fecha)
           WHEN 1 THEN 'Dom'
           WHEN 2 THEN 'Lun'
           WHEN 3 THEN 'Mar'
           WHEN 4 THEN 'Mié'
           WHEN 5 THEN 'Jue'
           WHEN 6 THEN 'Vie'
           WHEN 7 THEN 'Sáb'
         END AS dia,
         SUM(total) AS ventas
       FROM Ventas
       GROUP BY dia
       ORDER BY DAYOFWEEK(fecha)`
    );

    // 3. Ventas por Categoría (Gráfico de Pastel)
    const [salesByCategory] = await pool.query(
      `SELECT 
         c.nombre, 
         SUM(dv.cantidad * dv.precio_unitario) AS monto
       FROM DetalleVentas dv
       JOIN Productos p ON dv.id_producto = p.id_producto
       JOIN Categorias c ON p.id_categoria = c.id_categoria
       GROUP BY c.nombre`
    );

    // 4. Productos Más Vendidos (Tabla)
    const [topProducts] = await pool.query(
      `SELECT 
         p.nombre, 
         SUM(dv.cantidad) AS unidadesVendidas, 
         SUM(dv.cantidad * dv.precio_unitario) AS ingresosGenerados
       FROM DetalleVentas dv
       JOIN Productos p ON dv.id_producto = p.id_producto
       GROUP BY p.nombre
       ORDER BY unidadesVendidas DESC
       LIMIT 5`
    );
    
    // 5. Ingresos Mensuales (Gráfico de Línea - simplificado)
    // (Una consulta real aquí sería más compleja, agrupando por mes/año)
    const [monthlyRevenue] = await pool.query(
      `SELECT 
         DATE_FORMAT(fecha, '%Y-%m') AS mes,
         SUM(total) AS ingresos
       FROM Ventas
       GROUP BY mes
       ORDER BY mes ASC
       LIMIT 6`
    );

    // 6. Resumen Fiscal (para la tarjeta de la DIAN)
    const [taxSummary] = await pool.query(
      `SELECT 
         SUM(subtotal) AS baseGravable, 
         SUM(iva) AS ivaGenerado, 
         SUM(total) AS totalFacturado
       FROM Ventas`
    );

    // 7. Enviamos todo al frontend
    res.json({
      kpis: kpis || {},
      salesByDay: salesByDay || [],
      salesByCategory: salesByCategory || [],
      topProducts: topProducts || [],
      monthlyRevenue: monthlyRevenue || [],
      taxSummary: taxSummary[0] || {}
    });

  } catch (error) {
    console.error('Error al generar reportes:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
});

export default router;