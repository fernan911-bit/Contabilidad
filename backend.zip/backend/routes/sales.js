// En: backend/routes/sales.js
import { Router } from 'express';
import pool from '../db.js'; // Importa la conexión a la BD

const router = Router();

// --- RUTA POST /api/sales ---
// (Procesar una nueva venta)
router.post('/', async (req, res) => {
  
  // Usamos una 'transacción' para asegurarnos de que todas las
  // operaciones (crear venta, guardar detalles, actualizar stock)
  // fallen o tengan éxito juntas.
  let connection;
  try {
    // 1. Obtenemos los datos del frontend (carrito y cliente)
    const { customerData, cart } = req.body;

    // 2. Verificamos que el carrito no esté vacío
    if (!cart || cart.length === 0) {
      return res.status(400).json({ message: 'El carrito está vacío' });
    }
    
    // 3. Iniciamos la conexión y la transacción
    connection = await pool.getConnection();
    await connection.beginTransaction();

    // 4. (Opcional) Buscamos el ID del cliente si ya existe
    let id_cliente = null;
    if (customerData.email) {
      const [userRows] = await connection.query('SELECT id_usuario FROM Usuarios WHERE email = ?', [customerData.email]);
      if (userRows.length > 0) {
        id_cliente = userRows[0].id_usuario;
      }
    }
    
    // 5. Calculamos el total (Subtotal e IVA)
    // (Lo calculamos en el backend para asegurarnos de que los precios son correctos)
    let subtotal = 0;
    for (const item of cart) {
      subtotal += item.price * item.quantity;
    }
    const iva = subtotal * 0.19; // IVA del 19%
    const total = subtotal + iva;

    // 6. Creamos la Venta en la tabla 'Ventas'
    // (Obtenemos los datos de la empresa para la factura simulada)
    const [empresaRows] = await connection.query('SELECT * FROM Empresa WHERE id_empresa = 1');
    const empresa = empresaRows[0];
    const numero_factura = `${empresa.resolutionPrefix || 'F'}-${empresa.currentInvoice + 1}`;
    const resolution_info = `Res. DIAN ${empresa.dianResolution || 'XXXX'} del ${empresa.resolutionDate || 'YYYY-MM-DD'}`;

    const [ventaResult] = await connection.query(
      `INSERT INTO Ventas (numero_factura, id_cliente, cliente_nombre, cliente_nit, cliente_email, cliente_telefono, cliente_direccion, subtotal, iva, total, resolution_info)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        numero_factura,
        id_cliente,
        customerData.name,
        customerData.nit,
        customerData.email,
        customerData.phone,
        customerData.address,
        subtotal,
        iva,
        total,
        resolution_info
      ]
    );
    
    const newVentaId = ventaResult.insertId;

    // 7. Guardamos cada producto del carrito en 'DetalleVentas' Y ACTUALIZAMOS EL STOCK
    for (const item of cart) {
      // 7a. Guardamos el detalle
      await connection.query(
        `INSERT INTO DetalleVentas (id_venta, id_producto, cantidad, precio_unitario)
         VALUES (?, ?, ?, ?)`,
        [newVentaId, item.id, item.quantity, item.price]
      );

      // 7b. ¡Actualizamos el stock del producto!
      await connection.query(
        'UPDATE Productos SET stock = stock - ? WHERE id_producto = ?',
        [item.quantity, item.id]
      );
    }
    
    // 8. Actualizamos el número de la factura actual en la tabla 'Empresa'
    await connection.query('UPDATE Empresa SET currentInvoice = currentInvoice + 1 WHERE id_empresa = 1');

    // 9. ¡ÉXITO! Confirmamos la transacción
    await connection.commit();

    // 10. Enviamos la respuesta al frontend
    res.status(201).json({ 
      message: '¡Venta procesada exitosamente!', 
      numero_factura: numero_factura 
    });

  } catch (error) {
    // 11. ¡ERROR! Si algo falló, revertimos todos los cambios
    if (connection) {
      await connection.rollback();
    }
    console.error('Error al procesar la venta:', error);
    res.status(500).json({ message: 'Error interno del servidor', error: error.message });
  } finally {
    // 12. Siempre liberamos la conexión
    if (connection) {
      connection.release();
    }
  }
});

export default router;