// En: backend/routes/dashboard.js
import { Router } from 'express';
import pool from '../db.js';

const router = Router();

// --- RUTA GET /api/dashboard/stats ---
// El frontend llamará a esta ruta para llenar el Dashboard
router.get('/stats', async (req, res) => {
  try {
    // 1. Obtenemos las Ventas del Mes (KPI 1)
    // SUM(total) suma la columna 'total' de todas las ventas
    const [salesResult] = await pool.query(
      `SELECT 
         SUM(total) AS totalVentas, 
         COUNT(*) AS numeroVentas 
       FROM Ventas 
       WHERE MONTH(fecha) = MONTH(CURRENT_DATE()) AND YEAR(fecha) = YEAR(CURRENT_DATE())`
    );
    const salesData = salesResult[0];

    // 2. Obtenemos el Stock (KPI 2 y 4)
    // SUM(stock) suma todo el stock.
    // COUNT(*) WHERE... cuenta los productos con stock bajo.
    const [stockResult] = await pool.query(
      `SELECT 
         SUM(stock) AS totalStock, 
         COUNT(*) AS alertasStock 
       FROM Productos 
       WHERE stock <= minStock`
    );
    const stockData = stockResult[0];

    // 3. Obtenemos las Ventas Recientes (Tabla)
    const [recentSales] = await pool.query(
      `SELECT numero_factura, cliente_nombre, total, fecha 
       FROM Ventas 
       ORDER BY fecha DESC 
       LIMIT 5` // Traemos solo las últimas 5
    );

    // 4. Obtenemos los Productos con Stock Bajo (Tabla)
    const [lowStockProducts] = await pool.query(
      `SELECT nombre, stock, minStock, codigo_unico 
       FROM Productos 
       WHERE stock <= minStock 
       ORDER BY stock ASC 
       LIMIT 5` // Traemos solo los 5 más bajos
    );

    // 5. Enviamos todo al frontend en un solo objeto
    res.json({
      stats: {
        totalVentas: salesData.totalVentas || 0,
        numeroVentas: salesData.numeroVentas || 0,
        totalStock: stockData.totalStock || 0,
        alertasStock: stockData.alertasStock || 0,
      },
      recentSales,
      lowStockProducts,
    });

  } catch (error) {
    console.error('Error al obtener estadísticas del dashboard:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
});

export default router;