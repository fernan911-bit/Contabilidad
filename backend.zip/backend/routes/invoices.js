// En: backend/routes/invoices.js
import { Router } from 'express';
import pool from '../db.js';

const router = Router();

// --- 1. RUTA GET /api/invoices ---
// (Leer TODAS las ventas para la lista principal)
router.get('/', async (req, res) => {
  try {
    // Pedimos las ventas, ordenadas por la más reciente
    const [ventas] = await pool.query(
      `SELECT 
         id_venta, 
         numero_factura, 
         cliente_nombre, 
         cliente_nit, 
         fecha, 
         total, 
         iva 
       FROM Ventas 
       ORDER BY fecha DESC`
    );
    res.json(ventas);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener facturas', error: error.message });
  }
});

// --- 2. RUTA GET /api/invoices/:id ---
// (Leer los detalles de UNA venta para el Dialog de "Vista Previa")
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // a. Obtenemos los datos de la Venta (cliente, totales, etc.)
    const [ventaRows] = await pool.query('SELECT * FROM Ventas WHERE id_venta = ?', [id]);
    if (ventaRows.length === 0) {
      return res.status(404).json({ message: 'Factura no encontrada' });
    }
    const venta = ventaRows[0];

    // b. Obtenemos los items (productos) de esa venta
    const [itemsRows] = await pool.query(
      `SELECT dv.cantidad, dv.precio_unitario, p.nombre AS nombre_producto
       FROM DetalleVentas dv
       JOIN Productos p ON dv.id_producto = p.id_producto
       WHERE dv.id_venta = ?`,
      [id]
    );

    // c. Obtenemos los datos de la empresa (el vendedor)
    const [empresaRows] = await pool.query('SELECT * FROM Empresa WHERE id_empresa = 1');
    const empresa = empresaRows[0];

    // d. Juntamos todo y lo enviamos
    res.json({
      venta,
      items: itemsRows,
      empresa
    });

  } catch (error) {
    console.error('Error al obtener detalle de factura:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
});

export default router;