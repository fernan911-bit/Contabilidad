// En: backend/routes/config.js
import { Router } from 'express';
import pool from '../db.js';

const router = Router();

// --- 1. RUTA GET /api/config ---
// (Leer la información de la empresa)
router.get('/', async (req, res) => {
  try {
    // La empresa siempre tiene id = 1
    const [rows] = await pool.query('SELECT * FROM Empresa WHERE id_empresa = 1');
    if (rows.length === 0) {
      return res.status(404).json({ message: 'No se encontró la configuración de la empresa' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener la configuración', error: error.message });
  }
});

// --- 2. RUTA PUT /api/config ---
// (Actualizar la información de la empresa)
router.put('/', async (req, res) => {
  try {
    const {
      nombre, nit, direccion, ciudad, pais, telefono, email, website,
      descripcion, logo_url, dianResolution, resolutionDate,
      resolutionPrefix, resolutionFrom, resolutionTo, currentInvoice
    } = req.body;

    // Actualizamos la empresa (que siempre es id = 1)
    await pool.query(
      `UPDATE Empresa SET 
         nombre = ?, nit = ?, direccion = ?, ciudad = ?, pais = ?, telefono = ?, email = ?, 
         website = ?, descripcion = ?, logo_url = ?, dianResolution = ?, resolutionDate = ?, 
         resolutionPrefix = ?, resolutionFrom = ?, resolutionTo = ?, currentInvoice = ?
       WHERE id_empresa = 1`,
      [
        nombre, nit, direccion, ciudad, pais, telefono, email, website,
        descripcion, logo_url, dianResolution, resolutionDate,
        resolutionPrefix, resolutionFrom, resolutionTo, currentInvoice
      ]
    );

    // Devolvemos la configuración actualizada
    const [rows] = await pool.query('SELECT * FROM Empresa WHERE id_empresa = 1');
    res.json(rows[0]);

  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar la configuración', error: error.message });
  }
});

export default router;