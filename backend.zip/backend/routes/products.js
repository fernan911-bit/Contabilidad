// En: backend/routes/products.js
import { Router } from 'express';
import pool from '../db.js';

const router = Router();

// --- 1. RUTA GET /api/products ---
// (Leer todos los productos para la tabla)
router.get('/', async (req, res) => {
  try {
    const [products] = await pool.query(
      `SELECT p.*, c.nombre as categoria_nombre 
       FROM Productos p 
       LEFT JOIN Categorias c ON p.id_categoria = c.id_categoria
       ORDER BY p.id_producto DESC`
    );
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener productos', error: error.message });
  }
});

// --- 2. RUTA GET /api/products/categories ---
// (Leer todas las categorías para los menús desplegables del formulario)
router.get('/categories', async (req, res) => {
  try {
    const [categories] = await pool.query('SELECT * FROM Categorias');
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener categorías', error: error.message });
  }
});

// --- 3. RUTA POST /api/products ---
// (Crear un nuevo producto)
router.post('/', async (req, res) => {
  try {
    const {
      codigo_unico, nombre, descripcion, precio, stock, minStock, 
      id_categoria, specs_processor, specs_ram, specs_storage, 
      specs_screen, specs_graphics, specs_os
    } = req.body;

    const [result] = await pool.query(
      `INSERT INTO Productos (
         codigo_unico, nombre, descripcion, precio, stock, minStock, id_categoria, 
         specs_processor, specs_ram, specs_storage, specs_screen, specs_graphics, specs_os
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        codigo_unico, nombre, descripcion, precio, stock, minStock, id_categoria,
        specs_processor, specs_ram, specs_storage, specs_screen, specs_graphics, specs_os
      ]
    );

    // Devolvemos el producto recién creado
    const [newProduct] = await pool.query('SELECT * FROM Productos WHERE id_producto = ?', [result.insertId]);
    res.status(201).json(newProduct[0]);

  } catch (error) {
    res.status(500).json({ message: 'Error al crear el producto', error: error.message });
  }
});

// --- 4. RUTA PUT /api/products/:id ---
// (Actualizar un producto existente)
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const {
      codigo_unico, nombre, descripcion, precio, stock, minStock, 
      id_categoria, specs_processor, specs_ram, specs_storage, 
      specs_screen, specs_graphics, specs_os
    } = req.body;

    await pool.query(
      `UPDATE Productos SET 
         codigo_unico = ?, nombre = ?, descripcion = ?, precio = ?, stock = ?, 
         minStock = ?, id_categoria = ?, specs_processor = ?, specs_ram = ?, 
         specs_storage = ?, specs_screen = ?, specs_graphics = ?, specs_os = ?
       WHERE id_producto = ?`,
      [
        codigo_unico, nombre, descripcion, precio, stock, minStock, id_categoria,
        specs_processor, specs_ram, specs_storage, specs_screen, specs_graphics, specs_os,
        id
      ]
    );

    // Devolvemos el producto actualizado
    const [updatedProduct] = await pool.query('SELECT * FROM Productos WHERE id_producto = ?', [id]);
    res.json(updatedProduct[0]);

  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar el producto', error: error.message });
  }
});

// --- 5. RUTA DELETE /api/products/:id ---
// (Borrar un producto)
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM Productos WHERE id_producto = ?', [id]);
    res.json({ message: 'Producto eliminado exitosamente' });
  } catch (error) {
    // Manejo de error si el producto está en una venta (MySQL no lo dejará borrar)
    if (error.code === 'ER_ROW_IS_REFERENCED_2') {
      return res.status(400).json({ message: 'No se puede eliminar: Este producto ya está en una venta. Primero elimine la venta.' });
    }
    res.status(500).json({ message: 'Error al eliminar el producto', error: error.message });
  }
});

export default router;