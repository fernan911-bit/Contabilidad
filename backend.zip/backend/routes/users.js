// En: backend/routes/users.js
import { Router } from 'express';
import pool from '../db.js';
import bcrypt from 'bcryptjs';

const router = Router();

// --- 1. RUTA GET /api/users ---
// (Leer todos los usuarios para la tabla)
router.get('/', async (req, res) => {
  try {
    // Excluimos la contraseña (hash) de la consulta por seguridad
    const [users] = await pool.query(
      "SELECT id_usuario, nombre, email, rol, status, createdAt, lastLogin FROM Usuarios ORDER BY nombre"
    );
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener usuarios', error: error.message });
    if (!password || password.length < 6) {
      return res.status(400).json({ message: 'La contraseña es requerida y debe tener al menos 6 caracteres' });
    }
    const [existing] = await pool.query('SELECT * FROM Usuarios WHERE email = ?', [email]);
  }
});

// --- 2. RUTA POST /api/users ---
// (Crear un nuevo usuario)
router.post('/', async (req, res) => {
  try {
    const { nombre, email, password, rol, status } = req.body;

    // Verificamos si el email ya existe
    const [existing] = await pool.query('SELECT * FROM Usuarios WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(400).json({ message: 'El correo electrónico ya está registrado' });
    }

    // Encriptamos la nueva contraseña
    const contrasena_hash = await bcrypt.hash(password, 10);

    // Insertamos el nuevo usuario
    const [result] = await pool.query(
      `INSERT INTO Usuarios (nombre, email, contrasena_hash, rol, status) 
       VALUES (?, ?, ?, ?, ?)`,
      [nombre, email, contrasena_hash, rol, status]
    );

    // Devolvemos el usuario recién creado (sin el hash)
    const [newUser] = await pool.query(
      'SELECT id_usuario, nombre, email, rol, status, createdAt FROM Usuarios WHERE id_usuario = ?', 
      [result.insertId]
    );
    res.status(201).json(newUser[0]);

  } catch (error) {
    res.status(500).json({ message: 'Error al crear el usuario', error: error.message });
  }
});

// --- 3. RUTA PUT /api/users/:id ---
// (Actualizar un usuario existente)
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, email, rol, status, password } = req.body; // 'password' es opcional

    let query = `
      UPDATE Usuarios SET nombre = ?, email = ?, rol = ?, status = ? 
      WHERE id_usuario = ?`;
    let params = [nombre, email, rol, status, id];

    // Si el usuario también quiere cambiar la contraseña
    if (password && password.length > 0) {
      const contrasena_hash = await bcrypt.hash(password, 10);
      query = `
        UPDATE Usuarios SET nombre = ?, email = ?, rol = ?, status = ?, contrasena_hash = ? 
        WHERE id_usuario = ?`;
      params = [nombre, email, rol, status, contrasena_hash, id];
    }
    
    await pool.query(query, params);

    // Devolvemos el usuario actualizado (sin el hash)
    const [updatedUser] = await pool.query(
      'SELECT id_usuario, nombre, email, rol, status, createdAt, lastLogin FROM Usuarios WHERE id_usuario = ?', 
      [id]
    );
    res.json(updatedUser[0]);

  } catch (error) {
    // Manejo de error si el email ya existe
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Error: Ese correo electrónico ya está en uso por otra cuenta.' });
    }
    res.status(500).json({ message: 'Error al actualizar el usuario', error: error.message });
  }
});

// --- 4. RUTA DELETE /api/users/:id ---
// (Borrar un usuario)
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // (Opcional: Deberíamos verificar que no se borre el último admin)
    
    await pool.query('DELETE FROM Usuarios WHERE id_usuario = ?', [id]);
    res.json({ message: 'Usuario eliminado exitosamente' });
  } catch (error) {
    // Manejo de error si el usuario tiene ventas (MySQL no lo dejará borrar)
    if (error.code === 'ER_ROW_IS_REFERENCED_2') {
      return res.status(400).json({ message: 'No se puede eliminar: Este usuario tiene ventas asociadas.' });
    }
    res.status(500).json({ message: 'Error al eliminar el usuario', error: error.message });
  }
});

export default router;