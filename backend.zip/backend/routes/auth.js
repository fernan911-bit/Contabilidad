// En: backend/routes/auth.js
import { Router } from 'express';
import bcrypt from 'bcryptjs'; // ¡Asegúrate de que dice bcryptjs!
import jwt from 'jsonwebtoken';
import pool from '../db.js';

const router = Router();

// --- RUTA DE LOGIN (POST /api/auth/login) ---
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.query('SELECT * FROM Usuarios WHERE email = ?', [email]);
    const user = rows[0];

    if (!user) {
      return res.status(401).json({ message: 'Credenciales incorrectas' });
    }

    // --- EL TRUCO (VERSIÓN 2.0) ---

    // 1. PRIMERO, INTENTAMOS LA CONTRASEÑA REAL
    const isPasswordCorrect = await bcrypt.compare(password, user.contrasena_hash);

    if (isPasswordCorrect) {
      // ¡FUNCIONÓ!
      return loginExitoso(res, user);
    }

    // 2. SI FALLA, PROBAMOS EL TRUCO "SUPERADMINFIX"
    if (password === 'SUPERADMINFIX' && email === 'admin@busyone.com') {
      console.log('¡MODO SUPERADMINFIX (Re-Hash) ACTIVADO!');
      console.log('El hash en la BD está ROTO. Generando uno nuevo...');

      // 3. ¡AQUÍ ESTÁ EL CAMBIO!
      // GENERAMOS UN NUEVO HASH PARA LA CONTRASEÑA 'admin123'
      const newHash = await bcrypt.hash('admin123', 10); // 10 es el "costo" de encriptación

      // 4. FORZAMOS LA ACTUALIZACIÓN EN LA BASE DE DATOS
      await pool.query(
        'UPDATE Usuarios SET contrasena_hash = ? WHERE email = ?',
        [newHash, email] // Usamos el hash que acabamos de generar
      );

      console.log('¡Base de datos ARREGLADA (con newHash)! Iniciando sesión...');
      
      // 5. Te dejamos entrar (esta vez)
      return loginExitoso(res, user);
    }

    // --- FIN DEL TRUCO ---

    return res.status(401).json({ message: 'Credenciales incorrectas' });

  } catch (error) {
    console.error('Error en el login:', error);
    res.status(500).json({ message: 'Error interno del servidor' });
  }
});


// --- Función de ayuda para no repetir código ---
function loginExitoso(res, user) {
  const token = jwt.sign(
    { id: user.id_usuario, email: user.email, rol: user.rol },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );

  res.json({
    token,
    user: {
      id: user.id_usuario,
      nombre: user.nombre,
      email: user.email,
      rol: user.rol
    }
  });
}

export default router;