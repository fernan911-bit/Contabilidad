// En: backend/index.js
import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import pool from './db.js';
import authRoutes from './routes/auth.js';
import dashboardRoutes from './routes/dashboard.js';
import productRoutes from './routes/products.js';
import userRoutes from './routes/users.js';
import salesRoutes from './routes/sales.js';
import invoiceRoutes from './routes/invoices.js';
import reportRoutes from './routes/reports.js';
import configRoutes from './routes/config.js';

const app = express();
const PORT = 3002;

// --- ¡AQUÍ ESTÁ EL ARREGLO! ---
// Configuración de CORS explícita para aceptar todo
const corsOptions = {
  origin: '*', // Permite CUALQUIER origen (para pruebas)
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'], // Permite todos los métodos
  allowedHeaders: ['Content-Type', 'Authorization'], // Permite los headers que usamos
};
app.use(cors(corsOptions));
// --------------------------------

app.use(express.json()); // Permite al servidor entender JSON

// --- Logger simple (Para ver qué peticiones llegan) ---
app.use((req, res, next) => {
  console.log(`Petición recibida: ${req.method} ${req.url}`);
  next();
});
// --------------------------------------------------

// --- Rutas ---
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/products', productRoutes);
app.use('/api/users', userRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/config', configRoutes);
// Ruta de prueba (ahora en /api)
app.get('/api', (req, res) => {
  res.send('¡El motor (backend) de Busy One está funcionando!');
});

app.listen(PORT, () => {
  console.log(`Servidor backend corriendo en http://localhost:${PORT}`);
});